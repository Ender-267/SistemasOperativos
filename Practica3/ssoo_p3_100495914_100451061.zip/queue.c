//SSOO-P3 23/24

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <pthread.h>
#include "queue.h"

#define FALSE 0
#define TRUE 1


//To create a queue
queue *queue_init(int size) {
    queue *q = (queue *) malloc(sizeof(queue));
    q->array = calloc(size, sizeof(element));
    q->size = 0;
    q->max_size = size;
    pthread_mutex_init(&q->holding, NULL);
    return q;
}

/* insertar un elemento en la cola */
int queue_put(queue *q, struct element *x) {
    pthread_mutex_lock(&q->holding);

    while (queue_full(q)) {
        /* mientras la cola este llena, esperar a que se actualize la cola */
        pthread_cond_wait(&q->update, &q->holding);
    }
    q->array[q->size] = x;
    q->size++; 
    pthread_cond_signal(&q->update);
    pthread_mutex_unlock(&q->holding);
    return 0;
}

// To Dequeue an element.
/* obtener un elemento de la cola */
struct element *queue_get(queue *q) {
    pthread_mutex_lock(&q->holding);
    struct element *element;
    while(queue_empty(q)){
        pthread_cond_wait(&q->update, &q->holding);
    }
    element = q->array[0];
    for(int i = 0; i<q->max_size-1;i++){
        q->array[i] = q->array[i+1];
    }
    q->array[q->max_size-1] = NULL;
    q->size--;
    pthread_cond_signal(&q->update);
    pthread_mutex_unlock(&q->holding);
    return element;
}

/* verificar si la cola está vacía */
int queue_empty(queue *q) {
    if (q->size == 0){
        return TRUE;
    } else {
        return FALSE;
    }
}

/* verificar si la cola está llena */
int queue_full(queue *q) {
    if (q->size == q->max_size){
        return TRUE;
    } else {
        return FALSE;
    }
}

/* destruir la cola */
int queue_destroy(queue *q) {
    pthread_mutex_destroy(&q->holding);
    pthread_cond_destroy(&q->update);
    free(q->array);
    free(q);
    return 0;
}
